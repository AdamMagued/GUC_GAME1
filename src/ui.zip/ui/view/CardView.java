package ui.view;

import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;

public class CardView extends StackPane {
    private static final double CARD_WIDTH = 100;
    private static final double CARD_HEIGHT = 140;
    private static final double CORNER_RADIUS = 10;
    
    private Rectangle background;
    private Text cardText;
    
    public CardView(String value, String suit) {
        // Create card background
        background = new Rectangle(CARD_WIDTH, CARD_HEIGHT);
        background.setFill(Color.WHITE);
        background.setStroke(Color.BLACK);
        background.setStrokeWidth(2);
        background.setArcWidth(CORNER_RADIUS);
        background.setArcHeight(CORNER_RADIUS);
        
        // Create card text
        cardText = new Text(value + "\n" + suit);
        cardText.setStyle("-fx-font-size: 18; -fx-font-weight: bold;");
        
        // Add elements to the card
        getChildren().addAll(background, cardText);
        
        // Add hover effect
        setOnMouseEntered(e -> background.setFill(Color.LIGHTGRAY));
        setOnMouseExited(e -> background.setFill(Color.WHITE));
    }
    
    public void setSelected(boolean selected) {
        if (selected) {
            background.setStroke(Color.BLUE);
            background.setStrokeWidth(3);
        } else {
            background.setStroke(Color.BLACK);
            background.setStrokeWidth(2);
        }
    }
} 