package ui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import ui.controller.GameViewController;

public class MainApp extends Application {
    private Stage primaryStage;
    private BorderPane rootLayout;
    private GameViewController gameViewController;

    @Override
    public void start(Stage primaryStage) {
        try {
            this.primaryStage = primaryStage;
            this.primaryStage.setTitle("Jackaroo Card Game");
            
            // Initialize root layout
            initRootLayout();
            
            // Show the game view
            showGameView();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initRootLayout() {
        try {
            // Load root layout from fxml file
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Show the scene containing the root layout
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void showGameView() {
        try {
            // Load game view
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/GameView.fxml"));
            AnchorPane gameView = (AnchorPane) loader.load();
            
            // Set game view into the center of root layout
            rootLayout.setCenter(gameView);
            
            // Get the controller
            gameViewController = loader.getController();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public GameViewController getGameViewController() {
        return gameViewController;
    }

    public static void main(String[] args) {
        launch(args);
    }
} 