package ui.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class GameViewController {
    @FXML
    private Label playerNameLabel;
    
    @FXML
    private Label scoreLabel;
    
    @FXML
    private Label statusLabel;
    
    @FXML
    private GridPane gameArea;
    
    private int score = 0;
    
    @FXML
    private void initialize() {
        // Initialize the game view
        updateStatus("Welcome to Jackaroo! Click 'New Game' to start.");
    }
    
    @FXML
    private void handleDrawCard() {
        // TODO: Implement draw card logic
        updateStatus("Drawing a card...");
    }
    
    @FXML
    private void handlePlayCard() {
        // TODO: Implement play card logic
        updateStatus("Playing a card...");
    }
    
    @FXML
    private void handleEndTurn() {
        // TODO: Implement end turn logic
        updateStatus("Ending turn...");
    }
    
    public void updateStatus(String message) {
        statusLabel.setText("Game Status: " + message);
    }
    
    public void updateScore(int newScore) {
        score = newScore;
        scoreLabel.setText(String.valueOf(score));
    }
    
    public void setPlayerName(String name) {
        playerNameLabel.setText(name);
    }
} 